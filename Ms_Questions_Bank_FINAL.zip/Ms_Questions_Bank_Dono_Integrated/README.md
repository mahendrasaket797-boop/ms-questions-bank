# MS Questions Bank — Android app

Prepared components:
- Firebase Android configuration
- Firebase initialization in Flutter
- Previous-year/Premium PDF UI
- Razorpay Standard Checkout flow: server order creation + client checkout + server signature verification
- OpenAI Responses API backend for AI Study Assistant

## What still requires your accounts
I cannot create/verify third-party financial or API credentials on your behalf. Do NOT paste OpenAI or Razorpay secrets into chat or into the Android app.

### 1) Flutter setup
Open this folder in Android Studio. If the `android/` platform folder is incomplete, run:

```bash
flutter create .
flutter pub get
```

Keep `android/app/google-services.json` after this step.

### 2) Backend
Inside `backend/`:

```bash
npm install
cp .env.example .env
npm start
```

Put your Razorpay Test Key ID/Secret and OpenAI API key in `.env` on the server only.

Deploy the backend to a public HTTPS host before using it from a real phone.

### 3) Run the Android app with the backend URL
Use your backend URL and Razorpay **Key ID** (not Secret):

```bash
flutter run --dart-define=BACKEND_URL=https://YOUR-BACKEND.example.com --dart-define=RAZORPAY_KEY_ID=rzp_test_xxxxx
```

For a release build:

```bash
flutter build apk --release --dart-define=BACKEND_URL=https://YOUR-BACKEND.example.com --dart-define=RAZORPAY_KEY_ID=rzp_live_xxxxx
```

### 4) Razorpay
Razorpay requires server-side order creation and server-side signature verification. Test in Test Mode before switching to Live Mode.

### 5) Firebase
The supplied `google-services.json` is already at `android/app/google-services.json` and matches package `com.msquestionsbank.app`.

## Important
The app is source-ready, but I cannot honestly claim a live APK/payment/AI service without your Flutter build environment, deployed backend, and your own third-party credentials.
