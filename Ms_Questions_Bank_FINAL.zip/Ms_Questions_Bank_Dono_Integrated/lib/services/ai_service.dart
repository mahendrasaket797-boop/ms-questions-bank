import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class AiService {
  Future<String> ask(String question) async {
    if (AppConfig.backendUrl.contains('YOUR-BACKEND')) {
      return 'AI backend URL set nahi hai. App ko --dart-define=BACKEND_URL=... ke saath run karein.';
    }
    try {
      final r = await http.post(
        Uri.parse('${AppConfig.backendUrl}/ask'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'question': question}),
      );
      final data = jsonDecode(r.body);
      if (r.statusCode == 200) return data['answer'] ?? 'No answer received.';
      return 'AI server error: ${r.statusCode}';
    } catch (_) {
      return 'AI server se connection nahi ho paaya.';
    }
  }
}
