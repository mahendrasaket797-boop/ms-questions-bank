import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class PaymentService {
  Future<Map<String, dynamic>> createOrder({required int amountPaise, required String receipt}) async {
    final response = await http.post(
      Uri.parse('${AppConfig.backendUrl}/create-order'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'amount': amountPaise, 'receipt': receipt}),
    );
    if (response.statusCode != 200) {
      throw Exception('Could not create payment order (${response.statusCode})');
    }
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  Future<bool> verifyPayment({required String orderId, required String paymentId, required String signature}) async {
    final response = await http.post(
      Uri.parse('${AppConfig.backendUrl}/verify-payment'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'razorpay_order_id': orderId,
        'razorpay_payment_id': paymentId,
        'razorpay_signature': signature,
      }),
    );
    if (response.statusCode != 200) return false;
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return data['verified'] == true;
  }
}
