import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final classes = [
      ('Class 10', Icons.school),
      ('Class 11', Icons.menu_book),
      ('Class 12', Icons.library_books),
      ('Graduation', Icons.account_balance),
    ];
    return SafeArea(
      child: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 120,
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          flexibleSpace: const FlexibleSpaceBar(title: Text('Ms Questions Bank')),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(delegate: SliverChildListDelegate([
            TextField(
              decoration: InputDecoration(
                hintText: 'Search question papers...',
                prefixIcon: const Icon(Icons.search),
                filled: true, fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 22),
            const Text('Choose Your Class', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              itemCount: classes.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35),
              itemBuilder: (_, i) => Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SubjectPage(title: classes[i].$1))),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(classes[i].$2, size: 38, color: Colors.blue),
                    const SizedBox(height: 8),
                    Text(classes[i].$1, style: const TextStyle(fontWeight: FontWeight.w600)),
                  ]),
                ),
              ),
            ),
            const SizedBox(height: 22),
            Card(
              color: Colors.blue,
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                leading: const CircleAvatar(backgroundColor: Colors.white, child: Icon(Icons.auto_awesome, color: Colors.blue)),
                title: const Text('AI Study Assistant', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                subtitle: const Text('Ask questions and get study help', style: TextStyle(color: Colors.white70)),
                trailing: const Icon(Icons.arrow_forward_ios, color: Colors.white),
              ),
            ),
            const SizedBox(height: 16),
            const Text('Quick Access', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const ListTile(leading: Icon(Icons.history_edu, color: Colors.blue), title: Text('Previous Year Papers'), subtitle: Text('10–12 and Graduation')),
            const ListTile(leading: Icon(Icons.workspace_premium, color: Colors.blue), title: Text('Premium PDFs'), subtitle: Text('Paid study material')),
          ])),
        ),
      ]),
    );
  }
}

class SubjectPage extends StatelessWidget {
  final String title;
  const SubjectPage({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: ListView(children: [
      for (final s in ['Physics', 'Chemistry', 'Biology', 'Mathematics', 'English'])
        ListTile(leading: const Icon(Icons.picture_as_pdf, color: Colors.blue), title: Text('$s Question Papers'), trailing: const Icon(Icons.chevron_right)),
    ]),
  );
}
