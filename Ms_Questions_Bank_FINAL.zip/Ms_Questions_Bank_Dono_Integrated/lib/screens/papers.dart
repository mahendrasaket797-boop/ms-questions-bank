import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../services/payment_service.dart';
import '../services/config.dart';

class PapersScreen extends StatefulWidget {
  const PapersScreen({super.key});
  @override
  State<PapersScreen> createState() => _PapersScreenState();
}

class _PapersScreenState extends State<PapersScreen> {
  late final Razorpay _razorpay;
  final PaymentService _payments = PaymentService();
  String? _pendingPaper;
  String? _pendingOrderId;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final papers = [
      ('Class 10 Science 2025', false),
      ('Class 12 Biology 2025', false),
      ('Graduation Biology Previous Year', true),
      ('Chemistry Notes PDF', true),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Question Papers')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: papers.length,
        itemBuilder: (_, i) => Card(
          child: ListTile(
            leading: const Icon(Icons.picture_as_pdf, color: Colors.red),
            title: Text(papers[i].$1),
            subtitle: Text(papers[i].$2 ? 'Premium • ₹19' : 'Free PDF'),
            trailing: papers[i].$2
                ? FilledButton(onPressed: () => _startPayment(papers[i].$1), child: const Text('Buy'))
                : const Icon(Icons.lock_open, color: Colors.green),
          ),
        ),
      ),
    );
  }

  Future<void> _startPayment(String paper) async {
    _pendingPaper = paper;
    try {
      final order = await _payments.createOrder(amountPaise: 1900, receipt: 'msqb_${DateTime.now().millisecondsSinceEpoch}');
      _pendingOrderId = order['id'] as String?;
      final options = {
        'key': AppConfig.razorpayKeyId,
        'amount': order['amount'],
        'currency': order['currency'] ?? 'INR',
        'name': 'MS Questions Bank',
        'description': paper,
        'order_id': order['id'],
        'timeout': 120,
      };
      _razorpay.open(options);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Payment setup error: $e')));
      }
    }
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    final orderId = _pendingOrderId;
    if (orderId == null) return;
    try {
      final verified = await _payments.verifyPayment(
        orderId: orderId,
        paymentId: response.paymentId ?? '',
        signature: response.signature ?? '',
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(verified ? 'Payment verified. ${_pendingPaper ?? 'PDF'} unlock ho gaya.' : 'Payment verification failed.')),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment verify nahi ho paaya.')));
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Payment failed or cancelled.')));
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('External wallet: ${response.walletName ?? 'wallet'}')));
  }
}
