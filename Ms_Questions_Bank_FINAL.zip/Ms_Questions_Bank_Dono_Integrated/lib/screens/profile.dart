import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Profile')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 45)),
      const SizedBox(height: 12),
      const Center(child: Text('Student', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const SizedBox(height: 24),
      Card(child: Column(children: const [
        ListTile(leading: Icon(Icons.download), title: Text('My Downloads')),
        ListTile(leading: Icon(Icons.shopping_bag), title: Text('My Purchases')),
        ListTile(leading: Icon(Icons.settings), title: Text('Settings')),
        ListTile(leading: Icon(Icons.help_outline), title: Text('Help & Support')),
      ])),
    ]),
  );
}
