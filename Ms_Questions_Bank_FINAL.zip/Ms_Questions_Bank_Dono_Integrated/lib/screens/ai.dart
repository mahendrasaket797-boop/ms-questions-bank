import 'package:flutter/material.dart';
import '../services/ai_service.dart';

class AiScreen extends StatefulWidget {
  const AiScreen({super.key});
  @override State<AiScreen> createState() => _AiScreenState();
}
class _AiScreenState extends State<AiScreen> {
  final controller = TextEditingController();
  final service = AiService();
  String answer = 'Ask me a study question.';
  bool loading = false;

  Future<void> ask() async {
    if (controller.text.trim().isEmpty) return;
    setState(() => loading = true);
    final result = await service.ask(controller.text.trim());
    setState(() { answer = result; loading = false; });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AI Study Assistant')),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Expanded(child: SingleChildScrollView(child: Card(
          child: Padding(padding: const EdgeInsets.all(18), child: Text(answer, style: const TextStyle(fontSize: 16))),
        ))),
        TextField(controller: controller, minLines: 1, maxLines: 4,
          decoration: InputDecoration(hintText: 'Example: Explain photosynthesis', border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)))),
        const SizedBox(height: 10),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: loading ? null : ask,
          icon: loading ? const SizedBox(width: 18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.send),
          label: Text(loading ? 'Thinking...' : 'Ask AI'),
        )),
      ]),
    ),
  );
}
