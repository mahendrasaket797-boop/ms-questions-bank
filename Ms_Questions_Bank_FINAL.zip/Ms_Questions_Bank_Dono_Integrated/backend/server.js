import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import crypto from 'crypto';

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8080;
const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID;
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5';

app.get('/health', (_, res) => res.json({ok: true}));

app.post('/create-order', async (req, res) => {
  try {
    if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) return res.status(500).json({error: 'Razorpay is not configured'});
    const amount = Number(req.body?.amount);
    if (!Number.isInteger(amount) || amount < 100) return res.status(400).json({error: 'Invalid amount'});
    const auth = Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString('base64');
    const r = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {'Authorization': `Basic ${auth}`, 'Content-Type': 'application/json'},
      body: JSON.stringify({amount, currency: 'INR', receipt: String(req.body?.receipt || '').slice(0, 40)})
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error: data});
    res.json(data);
  } catch (e) { res.status(500).json({error: 'Order creation failed'}); }
});

app.post('/verify-payment', (req, res) => {
  const {razorpay_order_id, razorpay_payment_id, razorpay_signature} = req.body || {};
  if (!RAZORPAY_KEY_SECRET || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) return res.status(400).json({verified: false});
  const expected = crypto.createHmac('sha256', RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  const verified = crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(String(razorpay_signature)));
  res.json({verified});
});

app.post('/ask', async (req, res) => {
  try {
    if (!OPENAI_API_KEY) return res.status(500).json({error: 'OpenAI is not configured'});
    const question = String(req.body?.question || '').trim();
    if (!question) return res.status(400).json({error: 'Question is required'});
    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json'},
      body: JSON.stringify({model: OPENAI_MODEL, input: `You are the AI Study Assistant for MS Questions Bank. Explain clearly for a student.\n\nQuestion: ${question}`})
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error: data});
    res.json({answer: data.output_text || 'No answer received.'});
  } catch (e) { res.status(500).json({error: 'AI request failed'}); }
});

app.listen(PORT, () => console.log(`MS Questions Bank backend running on ${PORT}`));
